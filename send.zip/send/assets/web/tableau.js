$(document).ready(function () {
    $('#tab').DataTable({
        language: {
            url: "DataTables/Plugins/i18n/French.lang"
        }
    });
});