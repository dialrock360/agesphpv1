<?php
    $base_url = "http://localhost/send/";
?>
