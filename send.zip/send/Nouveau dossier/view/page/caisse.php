<?php
require_once 'caisse/caissecontent.php';
?>
<?php
require_once 'bloc/scriptcaisse.php';
?>
