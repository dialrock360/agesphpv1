
<ul class="nav nav-tabs" id="myTab">


    <li >
        <a onclick="UnsheckAll()" data-toggle="tab" href="#dropdown1">
            <i class="green ace-icon fa fa-money bigger-120"></i>
            Caisse

            &nbsp;

        </a>
    </li>

    <li class="active">
        <a onclick="UnsheckAll()" data-toggle="tab" href="#dropdown2">
            <i class="green ace-icon glyphicon glyphicon-tower bigger-120"></i>

            etat Comptes
            &nbsp;

        </a>
    </li>
    <li >
        <a onclick="UnsheckAll()" data-toggle="tab" href="#dropdown3">
            <i class="green ace-icon glyphicon glyphicon-usd bigger-120"></i>

            Bilan comptable
            &nbsp;
        </a>
    </li>

    <li >
        <a onclick="UnsheckAll()" data-toggle="tab" href="#dropdown4">
            <i class="green ace-icon fa fa-users bigger-120"></i>


            Paies
            &nbsp;

            <span class="badge badge-danger">
    <i class="green ace-icon fa fa-money bigger-50"></i>
        </a>
    </li>


</ul>