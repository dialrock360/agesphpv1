<style>
    /* #user,#cli,#four,#formcli,#formfour{
         display: none;
     }*/
</style>
<div class="row">
    <div class="col-xs-12">

  <?php
                   // require_once 'view/page/form/formeconfigetat.php';
                    ?>
                </style>
        <!-- PAGE CONTENT ENDS -->
    </div><!-- /.col -->
</div><!-- /.row -->
