<p style="margin-left:40px; text-align:right">
    <span style="font-family:courier new,courier,monospace">Dakar; le</span>
    </p>
     <div>
         <p style="margin-left:40px">
        <span style="font-family:courier new,courier,monospace">
            <strong>ANTREPRISE:<br />
                BP :<br />
                T&eacute;l/Fax :<br />
                Email </strong>:</span>
         </p>
         <table align="center" border="1" cellpadding="1" cellspacing="1" style="width:800px">
             <thead>
             <tr>
                 <th colspan="7" scope="col" style="text-align: center;">
                     <h1>
                         <span style="color:#0000FF">
                             <u>
                                 <strong>
                                     <span style="background-color:#D3D3D3">
                                         RAPPORT DU&nbsp;&nbsp;DU&nbsp;MOI DE fevrier 2018
                                     </span></strong></u></span>
                     </h1>
                 </th>
             </tr>
             </thead>
             <tbody>
             <tr>
                 <td rowspan="1" style="text-align:center">
                     <h2><strong><span style="color:black">Dates </span>
                         </strong>
                     </h2>
                 </td>
                 <td rowspan="1" style="text-align:center">
                     <h2 style="text-align:center">
                         <strong>
                             <span style="color:black">
                                 Domaines
                             </span>
                         </strong>
                     </h2>
                 </td>
                 <td rowspan="1" style="text-align:center">
                     <h2 style="text-align: center;">
                         <strong>
                             <span style="color:black">
                                 D&eacute;penses
                             </span>
                         </strong>
                     </h2>
                 </td>
                 <td rowspan="1" style="text-align:center"> <h2><strong>Gains</strong></h2> </td>
             </tr>
             <tr> <td colspan="1" rowspan="2" style="text-align:center"> <h2 style="text-align:center"><font color="#000000"><strong>15-02-2558</strong></font></h2> </td> <td style="text-align:center">bar</td> <td style="text-align:center">1151511515151515</td> <td style="text-align:center">5565656556</td> </tr>
             <tr> <td style="text-align:center">boutique</td> <td style="text-align:center">5575785</td> <td style="text-align:center">12127742</td> </tr>
             <tr> <td colspan="4" style="text-align:center">&nbsp;</td> </tr>
             <tr> <td colspan="4" style="text-align:center"> <table align="center" border="0.5" cellpadding="2" cellspacing="2" style="width:700px"> <tbody> <tr> <td colspan="4"> <h1 style="text-align:center"><span style="color:#FFFFFF"><strong><span style="background-color:#2F4F4F">FICHE RECAPITULATIVE</span></strong></span></h1> </td> </tr> <tr> <td> <p style="text-align: center;"><span style="font-family:tahoma,geneva,sans-serif"><em><strong><span style="background-color:#FFFFE0">DOMAINE</span></strong></em></span></p> </td> <td><em><strong><span style="background-color:rgb(255, 255, 224)">RECETTES</span></strong></em></td> <td> <p>&nbsp;</p> <pre> <span style="font-family:tahoma,geneva,sans-serif"><em><span style="color:black"><span style="background-color:#FFFFE0">DEPENSES </span></span></em></span></pre> </td> <td> <pre style="text-align:center"> <span style="font-family:tahoma,geneva,sans-serif"><em><span style="color:black"><span style="background-color:#FFFFE0">DIFFERENCE </span></span></em></span></pre> </td> </tr> <tr> <td>CHARGES</td> <td>15000</td> <td>2000</td> <td><span style="font-size:16px"><strong><span style="color:#0000FF"><span style="background-color:#FFFFFF">50000</span></span></strong></span></td> </tr> <tr> <td>BAR</td> <td>8000</td> <td>5555</td> <td><span style="font-size:16px"><strong><span style="color:#B22222"><span style="background-color:#FFFFFF">-8988</span></span></strong></span></td> </tr> <tr> <td colspan="4">&nbsp;</td> </tr> <tr> <td> <h2><strong>TOTAL</strong></h2> </td> <td> <h3><strong>230000</strong></h3> </td> <td> <h3><strong>25555</strong></h3> </td> <td> <h3><strong><span style="background-color:#D3D3D3">154888</span></strong></h3> </td> </tr> </tbody> </table> <p>&nbsp;</p> </td> </tr>
             </tbody>
          </table>
         <h2 style="margin-left:40px; text-align:center">
             ...</h2>
         <p>M. (<strong>Nom et Prenom</strong>), Titre ou poste dans la structure</p> </div>