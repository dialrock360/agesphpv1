
<?php

if(isset($_POST['conten'])){
	echo htmlentities($_POST['conten']) ;
}