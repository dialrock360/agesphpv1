<?php
/**
 * Created by PhpStorm.
 * User: D
 * Date: 03/03/2018
 * Time: 19:51
 */


require_once "bd.php";
require_once "functions.php";
require_once "functionsCount.php";
require_once "functionsuser.php";
require_once "functionsPrd.php";
require_once "functionsfac.php";
require_once "functionsTest.php";
require_once "functionsInsert.php";
require_once "functionsUpdate.php";
require_once "functionsDelete.php";
require_once "functionsRestor.php";
require_once "echotest.php";
Chargecleaner();Roomcleaner();