<?php
require_once 'view/page/printer/printpagecontent.php';
?>
