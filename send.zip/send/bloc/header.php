<?php
/*if ($file=='caisse'){
    require_once 'headerhome.php';
}else{
    require_once 'headerhome.php';
}*/
require_once 'headerhome.php';
?>