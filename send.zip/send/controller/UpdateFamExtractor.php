<?php
$ifa = $_POST["Aname$i"];
$nom = $_POST["Bname$i"];
$col = $_POST["Cname$i"];
$dep  = $_POST["Dname$i"];
$gain = $_POST["Ename$i"];
$stk = $_POST["Fname$i"];
$val='nom';
$idn = $_POST["idn"];

?>