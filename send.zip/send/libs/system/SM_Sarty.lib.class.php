<?php
function getSmarty(){
    return new Smarty();
}
?>