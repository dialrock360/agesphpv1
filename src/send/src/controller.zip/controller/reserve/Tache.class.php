<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



    /*==================Classe creer par Samane samane_ui_admin le 05-11-2019 09:59:47=====================*/
 use libs\system\Controller;
  use src\entities\Tache as TacheEntity;
  use src\model\TacheDB;

  use src\entities\Projet as ProjetEntity;
  use src\model\ProjetDB;


  class Tache extends Controller{

    /*==================Attribut list=====================*/
             private  $projet;
             private  $projetdb;


    /*================== Constructor =====================*/
              public function __construct()
                 {
                        parent::__construct();
                 $this->projet = new ProjetEntity();
                 $this->projetdb = new ProjetDB();
                 }


            //A noter que toutes les views de ce controller doivent être créées dans le dossier view/test
                //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
    /*------------------Methode index--------------------=*/
                
                public function index(){
                    return $this->view->load("tache/index");
                }

    /*------------------Methode Atelier--------------------=*/

                public function atelier(){
                    $data["view"] = 'AtelierProduction';
                    $data["curenview"] = 'Atelier de Production D\'Article composés';
                    $data["vewContent"] = 'formatelier';
                    $data["vewContenttype"] = 'form';
                    $data["pageheader"] = 'Atelier Manager';
                    $data["pageoverview"] = 'Ajouter un Atelier';
                    $data["active"] = 3;

                    return $this->view->load("index/index", $data);
                }


                public function atelierliste(){
                    $data["view"] = 'AtelierProduction';
                    $data["curenview"] = 'Atelier List';
                    $data["vewContent"] = 'listeatelier';
                    $data["vewContenttype"] = 'table';
                    $data["pageheader"] = 'Liste Ateliers de Production';
                    $data["pageoverview"] = 'Consulter les Ateliers';
                    $data["active"] = 3;

                    return $this->view->load("index/index", $data);
                }


    /*------------------Methode getID--------------------=*/
                
                public function getID( $id){
                    $data["id"] = $id;
                    return $this->view->load("tache/get_id", $data);
                }


    /*------------------Methode get--------------------=*/
                
                public function get($id){
                    //Instanciation du model
                    $tdb = new TacheDB();
                    $data["tache"] = $tdb->getTache($id);
                    return $this->view->load("tache/get", $data);
                }


    /*------------------Methode list--------------------=*/
                
            public function liste(){
                    //Instanciation du model
                    $tdb = new TacheDB();
                    $data["taches"] = $tdb->listeTache();
                    return $this->view->load("tache/liste", $data);
                }


    /*------------------..............--------------------=*/
    /*------------------Methode add--------------------=*/
                
public function add(){
	//Instanciation du model
            $tdb = new TacheDB();
    /*==================Foreign list=====================*/
                    $data["projets"] = $this->projetdb->listeProjet();
	//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST["valider"]))//"valider" est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                $data["ok"] = 0;
                if(!empty($id_projet)) {
                    $tacheObject  = new TacheEntity();
                    $tacheObject ->setId_projet($id_projet);
                    $tacheObject ->setNom_tache($nom_tache);
                    $tacheObject ->setLs_membre_tache($ls_membre_tache);
                    $tacheObject ->setDate_tache($date_tache);
                    $tacheObject ->setDatelimit_tache($datelimit_tache);
                    $tacheObject ->setEtiquette_tache($etiquette_tache);
                    $tacheObject ->setEtat_tache($etat_tache);
                    $tacheObject ->setInfo_tache($info_tache);
                    $ok = $tdb->addTache($tacheObject );
                    $data["ok"] = $ok;
                }
                return $this->view->load("tache/add", $data);
            }else{
                return $this->view->load("tache/add", $data);
            }
        }


    /*------------------Methode update--------------------=*/
                
		public function update(){
			//Instanciation du model
            $tdb = new TacheDB();
            if(isset($_POST["modifier"])){
                extract($_POST);
                if(!empty($id_projet)) {
                    $tacheObject  = new TacheEntity();
                    $tacheObject ->setId($id);
                    $tacheObject ->setId_projet($id_projet);
                    $tacheObject ->setNom_tache($nom_tache);
                    $tacheObject ->setLs_membre_tache($ls_membre_tache);
                    $tacheObject ->setDate_tache($date_tache);
                    $tacheObject ->setDatelimit_tache($datelimit_tache);
                    $tacheObject ->setEtiquette_tache($etiquette_tache);
                    $tacheObject ->setEtat_tache($etat_tache);
                    $tacheObject ->setInfo_tache($info_tache);
                    $ok = $tdb->updateTache($tacheObject );
                }
            }
            return $this->liste();
       }

    /*------------------Methode list--------------------=*/
                
            public function delete($id){
              //Instanciation du model
                    $tdb = new TacheDB();
            			//Supression
            			$tdb->deleteTache($id);
            //Retour vers la liste
                    return $this->liste();
                }


    /*------------------..............--------------------=*/
    /*------------------Methode edit--------------------=*/
                
            	public function edit($id){
                        //Instanciation du model
                       $tdb = new TacheDB();
    /*==================Foreign list=====================*/
                    $data["projets"] = $this->projetdb->listeProjet();
            			//Supression
            			$data["tache"] = $tdb->getTache($id);
            			//chargement de la vue edit.html
                    return $this->view->load("tache/edit", $data);
                   }




                   



               }


            ?>

