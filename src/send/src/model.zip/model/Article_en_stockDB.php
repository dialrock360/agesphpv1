<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Article_en_stock;

    /*==================Classe creer par Samane samane_ui_admin le 23-09-2019 16:11:41=====================*/
        class Article_en_stockDB extends Model {






				/*================== Constructor =====================*/

					public function __construct(){
					                      parent::__construct();
					        }


				/*================== Count article_en_stock =====================*/

							public function countArticle_en_stock(){
								$sql = "SELECT * FROM v_article_en_stock";
								if($this->db != null)
								{
									return $this->db->query($sql)->rowCount();
								}else{
									return null;
								}
							}
				/*================== Get article_en_stock =====================*/
					public function getArticle_en_stock($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE v_article_en_stock.id = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetch();
					                    }else{
					                        return null;
					                    }
					                }
					public function getArticle_en_stockBystkart($article_en_stock){
						$sql = "SELECT * FROM article_en_stock WHERE id_article=".$article_en_stock->getId_article()." and 
							article_en_stock.id_stock =  ".$article_en_stock->getId_stock()." 
							 ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetch();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== Liste article_en_stock =====================*/

					public function listeArticle_en_stock(){
					                $sql = "SELECT * FROM v_article_en_stock";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticle_en_stockbar($id){
					                $sql = "SELECT * FROM v_article_en_stock WHERE v_article_en_stock.id != ".$id."";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticle_en_stockbar_bar($id,$id_stock){
					                $sql = "SELECT * FROM v_article_en_stock WHERE v_article_en_stock.id != ".$id." and v_article_en_stock.id_stock != ".$id_stock." ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== Many to one article_en_stock =====================*/
					public function listeArticle_en_stockByArticleId($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE  v_article_en_stock.id_article = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticle_en_stockByConditionement_articleId($id){
					$sql = "SELECT * FROM article_en_stock WHERE  article_en_stock.id_conditionement_article = ".$id." and  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticle_en_stockByStockId($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE  v_article_en_stock.id_stock = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticle_en_stockByStockIdBar($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE  v_article_en_stock.id_stock != ".$id."  and qnt_article_en_stock > 0 and type_stock='dynamic'";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
//SELECT `id`, `id_article`, `id_stock`, `id_conditionement_article`, `pu_article_en_stock`,
// `qnt_article_en_stock`, `min_qnt_article_en_stock`, `max_qnt_article_en_stock`, `id_conditionement`,
// `qnt_unite`, `prix_unite`, `id_unite`, `nom_article`, `nom_conditionement`, `nom_uniteconditionement` FROM `v_article_en_stock` WHERE 1
					public function article_en_stocks_finis($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE  qnt_article_en_stock=0 and v_article_en_stock.id_stock = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }

					public function article_en_stocks_bas($id){
					$sql = "SELECT * FROM v_article_en_stock WHERE  qnt_article_en_stock<min_qnt_article_en_stock and qnt_article_en_stock!=0 and v_article_en_stock.id_stock = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== One to many article_en_stock =====================*/
					public function listeArticleByArticle_en_stockId($id_article){
					$sql = "SELECT * FROM article WHERE  article.id_article = ".$id_article."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeConditionement_articleByArticle_en_stockId($id_conditionement_article){
					$sql = "SELECT * FROM conditionement_article WHERE  conditionement_article.id_conditionement_article = ".$id_conditionement_article."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeStockByArticle_en_stockId($id_stock){
					$sql = "SELECT * FROM stock WHERE  stock.id_stock = ".$id_stock."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }


//(`id`, `ref_article`, `id_article`, `id_stock`,
// `id_conditionement_article`, `qnt_article_en_stock`,
// `valeur_article_en_stock`, `min_qnt_article_en_stock`,
// `max_qnt_article_en_stock`)
// `max_qnt_article_en_stock`)

	public function addArticle_en_stock($article_en_stock){
		   $sql = "INSERT INTO article_en_stock  (`id`, `ref_article`, `id_article`, `id_stock`,  
`qnt_article_en_stock`, `valeur_article_en_stock`, `min_qnt_article_en_stock`, `max_qnt_article_en_stock`)
VALUES(
                                     null
,
                                     '".$article_en_stock->getRef_article()."'
,
                                     ".$article_en_stock->getId_article()."
,
                                     ".$article_en_stock->getId_stock()."
,
                                     '".$article_en_stock->getQnt_article_en_stock()."'
,
                                     '".$article_en_stock->getValeur_article_en_stock()."'
,
                                     '".$article_en_stock->getMin_qnt_article_en_stock()."'
,
                                     '".$article_en_stock->getMax_qnt_article_en_stock()."'
) ";

		 if($this->db != null)
		{
			$this->db->exec($sql);
			return $this->db->lastInsertId();//Si la clé primaire est auto_increment
		}else{
			return null;
		}
	}


	public function updatearticle_en_stock($article_en_stock){
	  	$sql = "UPDATE article_en_stock  SET  
            article_en_stock.ref_article =  '".$article_en_stock->getRef_article()."' ,
            article_en_stock.id_article =  '".$article_en_stock->getId_article()."' ,
            article_en_stock.qnt_article_en_stock =  '".$article_en_stock->getQnt_article_en_stock()."' ,
            article_en_stock.valeur_article_en_stock =  '".$article_en_stock->getValeur_article_en_stock()."' ,
            article_en_stock.min_qnt_article_en_stock =  '".$article_en_stock->getMin_qnt_article_en_stock()."' ,
            article_en_stock.max_qnt_article_en_stock =  '".$article_en_stock->getMax_qnt_article_en_stock()."'   WHERE   article_en_stock.id =  ".$article_en_stock->getId()."  ";

		 if($this->db != null)
		{
			return $this->db->exec($sql);
		}else{
			return null;
		}
	}

	public function update_qnt_article_en_stock($article_en_stock){
	  	$sql = "UPDATE article_en_stock  SET   
            article_en_stock.qnt_article_en_stock =  '".$article_en_stock->getQnt_article_en_stock()."' ,
            article_en_stock.valeur_article_en_stock =  '".$article_en_stock->getValeur_article_en_stock()."'     WHERE   article_en_stock.id =  ".$article_en_stock->getId()."  ";

		 if($this->db != null)
		{
			return $this->db->exec($sql);
		}else{
			return null;
		}
	}


				/*================== Delete article_en_stock =====================*/
					public function deleteArticle_en_stock($id){
					$sql = "DELETE FROM article_en_stock WHERE article_en_stock.id = ".$id."";
					                if($this->db != null)
					                    {
					                        return $this->db->exec($sql);
					                    }else{
					                        return null;
					                    }
					                }

				/*================== If article_en_stock existe =====================*/

			/*
			 * SELECT `id`, `id_article`, ``, ``, `pu_article_en_stock`,
			 *  `qnt_article_en_stock`, `min_qnt_article_en_stock`, `max_qnt_article_en_stock` FROM `article_en_stock` WHERE 1
			 */



						public function ifArticle_en_stockexiste($article_en_stock){
							$sql = "SELECT * FROM article_en_stock WHERE id_article=".$article_en_stock->getId_article()." and 
							article_en_stock.id_stock =  ".$article_en_stock->getId_stock()." 
							 ";
							if($this->db != null)
							{
								if($this->db->query($sql)->fetch() != null)
								{
									return 1;
								}
							}
							return 0;
						}


           }
  
   



   ?>



