<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Users;

    /*==================Classe creer par Samane samane_ui_admin le 14-09-2019 00:33:41=====================*/
        class UsersDB extends Model {


    /*================== Constructor =====================*/
              public function __construct()
                 {
                        parent::__construct();
                 }


               public function countUsers(){
                        return count($this->listeUsers());
               }

               public function getUsers($id){
                      $sql = "SELECT *
                              FROM users
                              WHERE users.id = ".$id."  ";
                      if($this->db != null)
                        {
                            return $this->db->query($sql)->fetch();
                        }else{
                        return null;
                        }
               }
               public function getConnexion($login,$password){

                      $sql = "SELECT *
                              FROM users
                              WHERE users.login = '".$login."' and  users.password = '".$password."' ";
                      if($this->db != null)
                        {
                            return $this->db->query($sql)->fetch();
                        }else{
                        return null;
                        }
               }
               public function listeUsers(){
                       $sql = "SELECT * FROM users";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================Many to one =====================*/



               public function listeUsersByServiceId($id){
                      $sql = "SELECT *
                              FROM users
                              WHERE id = ".$id."  ";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================One to many =====================*/
                public function listeServiceByUsersId($id){
                      $sql = "SELECT *
                              FROM service
                              WHERE id = ".$id."  ";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================********************* =====================*/

    /*==================Add methode=====================*/
                
               public function addUsers($users){
                        $sql = "INSERT INTO users  VALUES(
                                     null
,
                                     '".$users->getId_service()."'
,
                                     '".$users->getLogin()."'
,
                                     '".$users->getPassword()."'
,
                                     '".$users->getLevelsecurity()."'
) ";

                      if($this->db != null)
                        {
                            $this->db->exec($sql);
                            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }

    /*==================Update methode=====================*/
                
               public function updateUsers($users){
                        $sql = "UPDATE users  SET  users.id_service =  '".$users->getId_service()."' ,users.login =  '".$users->getLogin()."' ,users.password =  '".$users->getPassword()."' ,users.levelsecurity =  '".$users->getLevelsecurity()."'   WHERE   users.id =  ".$users->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

               public function deleteUsers($id){
                        $sql = "DELETE FROM users WHERE users.id = ".$id."";
                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
           }
  
   



   ?>



