<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Conditionement;

    /*==================Classe creer par Samane samane_ui_admin le 14-09-2019 00:33:39=====================*/
        class ConditionementDB extends Model {


    /*================== Constructor =====================*/
              public function __construct()
                 {
                        parent::__construct();
                 }


               public function countConditionement(){
                        return count($this->listeConditionement());
               }

               public function getConditionement($id){
                      $sql = "SELECT *
                              FROM conditionement
                              WHERE conditionement.id = ".$id."  ";
                      if($this->db != null)
                        {
                            return $this->db->query($sql)->fetch();
                        }else{
                        return null;
                        }
               }
               public function listeConditionement(){
                       $sql = "SELECT * FROM conditionement WHERE  flag_conditionement=0 order by nom_conditionement";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================Add methode=====================*/
                
               public function addConditionement($conditionement){
                        $sql = "INSERT INTO conditionement  VALUES(
                                     null
,
                                     '".$conditionement->getNom_conditionement()."',0,0
) ";

                      if($this->db != null)
                        {
                            $this->db->exec($sql);
                            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }

    /*==================Update methode=====================*/
                
               public function updateConditionement($conditionement){
                     $sql = "UPDATE conditionement  SET  conditionement.nom_conditionement =  '".$conditionement->getNom_conditionement()."' , 
                        conditionement.nbr_utilisation =  ".$conditionement->getNbrUtilisation()." 
                          WHERE   conditionement.id =  ".$conditionement->getId()."  ";

                     if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

               public function deleteConditionement($id){
                        $sql = "DELETE FROM conditionement WHERE conditionement.id = ".$id."";
                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
            public function fldeleteConditionement($id){
                $sql = "UPDATE conditionement  SET  article.flag_conditionement = 1  WHERE   conditionement.id =  ".$id."  ";
                if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
            public function ifConditionementexiste($conditionement){
                $sql = "SELECT * FROM conditionement WHERE   conditionement.nom_conditionement =  '".$conditionement->getNom_conditionement()."' ";
                if($this->db != null)
                {
                    if($this->db->query($sql)->fetch() != null)
                    {
                        return 1;
                    }
                }
                return 0;
            }
           }
  
   



   ?>



