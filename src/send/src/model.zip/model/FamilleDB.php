<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Famille;

    /*==================Classe creer par Samane samane_ui_admin le 14-09-2019 00:33:40=====================*/
        class FamilleDB extends Model {


    /*================== Constructor =====================*/
              public function __construct()
                 {
                        parent::__construct();
                 }


               public function countFamille(){
                        return count($this->listeFamille());
               }

               public function getFamille($id){
                      $sql = "SELECT *
                              FROM famille
                              WHERE famille.id = ".$id."  ";
                      if($this->db != null)
                        {
                            return $this->db->query($sql)->fetch();
                        }else{
                        return null;
                        }
               }
               public function listeFamille(){
                       $sql = "SELECT * FROM famille";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================Many to one =====================*/



               public function listeFamilleByServiceId($id){
                      $sql = "SELECT *
                              FROM famille
                              WHERE id_service = ".$id." and flag_famille=0 order by  nom_famille";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================One to many =====================*/
                public function listeServiceByFamilleId($id){
                      $sql = "SELECT *
                              FROM service
                              WHERE id = ".$id."  ";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================********************* =====================*/

    /*==================Add methode=====================*/
                
               public function addFamille($famille){
                        $sql = "INSERT INTO famille  VALUES(
                                     null
,
                                     '".$famille->getId_service()."'
,
                                     '".$famille->getNom_famille()."'
,
                                     '".$famille->getColor_famille()."'
,
                                     '".$famille->getNbr_categorie_famille()."'
,
                                     '".$famille->getValeurFamille()."'
,
                                     '".$famille->getFlag_famille()."'
) ";

                      if($this->db != null)
                        {
                            $this->db->exec($sql);
                            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }

    /*==================Update methode=====================*/
                
               public function updateFamille($famille){
                        $sql = "UPDATE famille  SET  famille.id_service =  '".$famille->getId_service()."' ,famille.nom_famille =  '".$famille->getNom_famille()."' ,famille.color_famille =  '".$famille->getColor_famille()."' ,famille.nbr_categorie_famille =  '".$famille->getNbr_categorie_famille()."' ,famille.flag_famille =  '".$famille->getFlag_famille()."'   WHERE   famille.id =  ".$famille->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
            public function flagupdate($id,$flag){
                $sql = "UPDATE famille  SET  famille.flag_famille =  ".$flag."   WHERE   famille.id =  ".$id."  ";

                if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
            public function nbrcategorieupdate($famille){
                   $id=$famille->getId();
                   $nbr=$famille->getNbr_categorie_famille();
                   $sql = "UPDATE famille SET famille.nbr_categorie_famille = ".$nbr." WHERE famille.id = ".$id." ";

               if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
            public function getnbrcategorieToupdate($id_service){

                $tabidfam=array();
                $sql = "SELECT *
                              FROM v_categorie
                             WHERE id_service = ".$id_service." and flag_categorie=0  order by  nom_categorie";
                   if($this->db != null)
            {
                $categories=$this->db->query($sql)->fetchAll();
                if($categories != null){
                    $familles=$this->listeFamilleByServiceId($id_service);
                    foreach ($familles as $famille){
                        $cptcat=0;
                        $cptfam=0;
                        $tabtmp=array();
                        foreach ($categories as $categorie){
                            if ($categorie['id_famille']==$famille['id']){
                                $cptcat++;
                                // print_r($categorie);
                                // echo '<br>';
                            }else{
                                $cptfam++;
                            }
                        }
                        if ($cptcat>0){

                            // echo '<hr>'.$famille['nom_famille'].' => '.$cptcat.' cat ';
                            // print_r($famille);
                            //  echo '<br>';
                            $tabtmp['id_famille']=$famille['id'];
                            $tabtmp['nbrcategorie']=$cptcat;
                            $tabidfam[]=$tabtmp;
                            // echo '<hr>';
                        }
                      /*  if ($cptfam>0){

                            // echo '<hr>'.$famille['nom_famille'].' => '.$cptcat.' cat ';
                            // print_r($famille);
                            //  echo '<br>';
                            $tabtmp['id_famille']=$famille['id'];
                            $tabtmp['nbrcategorie']=0;
                            $tabidfam[]=$tabtmp;
                            // echo '<hr>';
                        }*/

                        // echo '<hr>';
                    }

                }


            }
               return $tabidfam;
            }
               public function deleteFamille($id){
                        $sql = "DELETE FROM famille WHERE famille.id = ".$id."";
                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

            public function fldeleteFamille($id){
                $sql = "UPDATE famille  SET  famille.flag_famille = 1  WHERE   famille.id =  ".$id."  ";
                if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
            public function ifFamilleexiste($famille){
                $sql = "SELECT * FROM famille WHERE id_service='".$famille->getId_service()."' and famille.nom_famille =  '".$famille->getNom_famille()."' ";
                if($this->db != null)
                {
                    if($this->db->query($sql)->fetch() != null)
                    {
                        return 1;
                    }
                }
                return 0;
            }
           }
  
   



   ?>



