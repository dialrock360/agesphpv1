<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Article;

    /*==================Classe creer par Samane samane_ui_admin le 06-11-2019 10:18:25=====================*/
        class ArticleDB extends Model {






				/*================== Constructor =====================*/

					public function __construct(){
					                      parent::__construct();
					        }


				/*================== Count article =====================*/
					public function countArticle(){
					                       return count($this->listeArticle());
					        }

				/*================== Get article =====================*/
					public function getArticle($id){
					$sql = "SELECT * FROM v_article WHERE v_article.id = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetch();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== Liste article =====================*/
					public function listeArticle(){
					                $sql = "SELECT * FROM article";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== Many to one article =====================*/
					public function listeArticleByCategorieId($id){
					$sql = "SELECT * FROM v_article WHERE  v_article.id_categorie = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeArticleByServiceId($id){
					$sql = "SELECT * FROM v_article WHERE  v_article.id_service = ".$id."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeChargeByServiceId($id){
					$sql = "SELECT * FROM v_article WHERE  v_article.id_service = ".$id."  and  v_article.type_article =0  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }

				/*================== One to many article =====================*/
					public function listeCategorieByArticleId($id_categorie){
					$sql = "SELECT * FROM categorie WHERE  categorie.id_categorie = ".$id_categorie."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
					public function listeServiceByArticleId($id_service){
					$sql = "SELECT * FROM service WHERE  service.id_service = ".$id_service."  ";
					                if($this->db != null)
					                    {
					                        return $this->db->query($sql)->fetchAll();
					                    }else{
					                        return null;
					                    }
					                }
			public function addArticle($article){

						//(`id`, `id_categorie`, `id_catalogue`, `fiche_technique`, `nbrstockage`, `tabidstock`, `flag_article`
				$sql = "INSERT INTO article  VALUES(
                                     null
,
                                      ".$article->getType_article()." 
,
                                     '".$article->getId_categorie()."'
,
                                     '".$article->getId_catalogue()."'
,
                                     '".$article->getFiche_technique()."'
,
                                     0
,
                                     ''
,
                                     0
,
                                     0
) ";

				if($this->db != null)
				{
					$this->db->exec($sql);
					return $this->db->lastInsertId();//Si la clé primaire est auto_increment
				}else{
					return null;
				}
			}

/*
               public function addArticle($article){
                        $sql = "INSERT INTO article  VALUES(
                                     null
,
                                     ".$article->getId_categorie()."
                                     ".$article->getRefArticle()."
,
                                     ".$article->getId_service()."
,
                                     '".$article->getNom_article()."'
,
                                     '".$article->getPxa_article()."'
,
                                     '".$article->getPxv_article()."'
,
                                     '".$article->getPxvbar_article()."'
,
                                     '".$article->getType_article()."'
,
                                     '".$article->getTabidp()."'
,
                                     '".$article->getTabqnt()."'
,
                                     '".$article->getTabmts()."'
,
                                     '".$article->getPxrv()."'
,
                                     '".$article->getFlag_article()."'
,
                                     '".$article->getNbrstockage()."'
,
                                     '".$article->getTabidstock()."'
) ";

                      if($this->db != null)
                        {
                              $this->db->exec($sql);
                              return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }
*/
               public function updatearticle2($article){
                        $sql = "UPDATE article  SET  
  article.type_article =  '".$article->getType_article()."' ,
 article.id_categorie =  '".$article->getId_categorie()."' ,
 article.nom_article =  '".$article->getNom_article()."' ,
 article.pxa_article =  '".$article->getPxa_article()."' ,
 article.pxv_article =  '".$article->getPxv_article()."' ,
 article.pxvbar_article =  '".$article->getPxvbar_article()."' , 
 article.pxrv =  '".$article->getPxrv()."'   
   WHERE   article.id =  ".$article->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
               public function updatearticle($article){
                        $sql = "UPDATE article  SET   article.id_categorie =  '".$article->getId_categorie()."' ,article.nom_article =  '".$article->getNom_article()."' ,article.pxa_article =  '".$article->getPxa_article()."' ,article.pxv_article =  '".$article->getPxv_article()."' ,article.pxvbar_article =  '".$article->getPxvbar_article()."' ,article.type_article =  '".$article->getType_article()."' ,article.tabidp =  '".$article->getTabidp()."' ,article.tabqnt =  '".$article->getTabqnt()."' ,article.tabmts =  '".$article->getTabmts()."' ,article.pxrv =  '".$article->getPxrv()."'  ,article.nbrstockage =  '".$article->getNbrstockage()."' ,article.tabidstock =  '".$article->getTabidstock()."'   WHERE   article.id =  ".$article->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

               public function updatearticle3($article){
                         $sql = "UPDATE article  SET 
  article.fiche_technique =  '".$article->getFiche_technique()."' ,
  article.id_categorie =   ".$article->getId_categorie()."  , 
  article.nbrstockage =   ".$article->getNbrstockage()."  ,
  article.tabidstock =  '".$article->getTabidstock()."' 
     WHERE   article.id =  ".$article->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

				/*================== Delete article =====================*/
					public function deleteArticle($id){
					$sql = "DELETE FROM article WHERE article.id = ".$id."";
					                if($this->db != null)
					                    {
					                        return $this->db->exec($sql);
					                    }else{
					                        return null;
					                    }
					                }

							public function fldeleteArticle($id){
								$sql = "UPDATE article  SET  article.flag_article = 1  WHERE   article.id =  ".$id."  ";
								if($this->db != null)
								{
									return $this->db->exec($sql);
								}else{
									return null;
								}
							}
							public function updatechampArticle($id,$nom_champ,$valeur ){
						//SELECT `id`, `type_article`, `id_categorie`, `id_catalogue`, `fiche_technique`, `nbrstockage`, `tabidstock`, `valeur_article`, `flag_article` FROM `article` WHERE 1

								$sql = "UPDATE article  SET  article.".$nom_champ." = '".$valeur."'  WHERE   article.id =  ".$id."  ";
								if($this->db != null)
								{
									return $this->db->exec($sql);
								}else{
									return null;
								}
							}

							public function updatevaleurArticle($id,$valeur_article){
								$sql = "UPDATE article  SET  article.valeur_article = ".$valeur_article."  WHERE   article.id =  ".$id."  ";
								if($this->db != null)
								{
									return $this->db->exec($sql);
								}else{
									return null;
								}
							}
							public function updatestockarticle($id,$Nbrstockage,$tabidstock){
								$sql = "UPDATE article  SET  article.nbrstockage =   ".$Nbrstockage."  ,article.tabidstock =  '".$tabidstock."' WHERE   article.id =  ".$id."  ";
								if($this->db != null)
								{
									return $this->db->exec($sql);
								}else{
									return null;
								}
							}
							public function updatearticlecomposer($article){
								$sql = "UPDATE article  SET  article.tabidp =  '".$article->getTabidp()."' ,article.tabqnt =  '".$article->getTabqnt()."' ,article.tabmts =  '".$article->getTabmts()."'  WHERE   article.id =  ".$article->getId()."   ";
								if($this->db != null)
								{
									return $this->db->exec($sql);
								}else{
									return null;
								}
							}

				/*================== If article existe =====================*/
					public function ifArticleexiste($nom_article,$id_service){
					$sql = "SELECT * FROM v_article WHERE nom_article='".$nom_article."' and id_service= ".$id_service."  ";
					if($this->db != null)
					      {
					       if($this->db->query($sql)->fetch() != null)
					         {
					                 return 1;
					         }
					      } 
					return 0;
					                }

			public function setNbrstockage($id,$Nbrstockage){
				  $sql = "UPDATE article  SET  article.nbrstockage  = $Nbrstockage   WHERE   article.id =  ".$id."  ";

				 if($this->db != null)
				{
					return $this->db->exec($sql);
				}else
					return null;
			}
           }
  
   



   ?>



