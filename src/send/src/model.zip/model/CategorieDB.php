<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\model;
use libs\system\Model;
  use src\entities\Categorie;
use src\entities\Categorie as CategorieEntity;

/*==================Classe creer par Samane samane_ui_admin le 14-09-2019 00:33:39=====================*/
        class CategorieDB extends Model {


    /*================== Constructor =====================*/
              public function __construct()
                 {
                        parent::__construct();
                 }


               public function countCategorie(){
                        return count($this->listeCategorie());
               }

               public function getCategorie($id){
                      $sql = "SELECT *
                              FROM v_categorie
                              WHERE  id = ".$id."  ";
                      if($this->db != null)
                        {
                            return $this->db->query($sql)->fetch();
                        }else{
                        return null;
                        }
               }
               public function listeCategorie(){
                       $sql = "SELECT * FROM categorie";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
    /*==================Many to one =====================*/





               public function listeCategorieByFamilleId($id){
                      $sql = "SELECT *
                              FROM categorie
                              WHERE id = ".$id."  ";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }

    /*==================One to many =====================*/
                public function listeFamilleByCategorieId($id){
                      $sql = "SELECT *
                              FROM famille
                              WHERE id = ".$id."  ";
                      if($this->db != null)
                        {
                              return $this->db->query($sql)->fetchAll();
                        }else{
                        return null;
                        }
               }
            public function listeCategorieByServiceId($id){
                $sql = "SELECT *
                              FROM v_categorie
                             WHERE id_service = ".$id." and flag_categorie=0  order by  nom_categorie";
                if($this->db != null)
                {
                    return $this->db->query($sql)->fetchAll();
                }else{
                    return null;
                }
            }
    /*==================********************* =====================*/

    /*==================Add methode=====================*/
                
               public function addCategorie($categorie){
                        $sql = "INSERT INTO categorie  VALUES(
                                     null 
,
                                     '".$categorie->getId_famille()."'
,
                                     '".$categorie->getNom_categorie()."'
,
                                     0
,
                                     0 
,
                                    '".$categorie->getId_nomenclature_article()."'
,
                                     0 
) ";

                      if($this->db != null)
                        {
                            $this->db->exec($sql);
                            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }
    /*==================Add methode=====================*/

               public function autocreateCategorie($categorie){
                        $sql = "INSERT INTO `categorie` VALUES (null ,  '".$categorie->getId_famille()."', 'Charges variable', 0, 0, 0)    ";

                      if($this->db != null)
                        {
                            $this->db->exec($sql);
                            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
                        }else{
                        return null;
                        }
               }

    /*==================Update methode=====================*/
                
               public function updateCategorie($categorie){
                        $sql = "UPDATE categorie  SET  categorie.id_famille =  '".$categorie->getId_famille()."' ,categorie.nom_categorie =  '".$categorie->getNom_categorie()."' ,categorie.nbr_produit_categorie =  '".$categorie->getNbr_produit_categorie()."' ,categorie.flag_categorie =  '".$categorie->getFlag_categorie()."' ,categorie.id_nomenclature_article =  '".$categorie->getId_nomenclature_article()."'   WHERE   categorie.id =  ".$categorie->getId()."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
            public function updatecategorie2($categorie){
                    $sql = "UPDATE categorie  SET   categorie.id_famille =  '".$categorie->getId_famille()."' ,categorie.nom_categorie =  '".$categorie->getNom_categorie()."' ,categorie.nbr_produit_categorie =  '".$categorie->getNbr_produit_categorie()."' ,categorie.id_nomenclature_article =  '".$categorie->getId_nomenclature_article()."'   WHERE   categorie.id =  ".$categorie->getId()."  ";

                 if($this->db != null)
                  {
                        return $this->db->exec($sql);
                  }else{
                  return null;
                  }
            }
               public function flagupdate($id,$flag){
                        $sql = "UPDATE categorie  SET  categorie.flag_categorie =  ".$flag."   WHERE   categorie.id =  ".$id."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }
               public function nbrarticleupdate2($id,$nbr){
                        $sql = "UPDATE categorie  SET  categorie.nbr_produit_categorie =  ".$nbr."   WHERE   categorie.id =  ".$id."  ";

                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

               public function deleteCategorie($id){
                        $sql = "DELETE FROM categorie WHERE categorie.id = ".$id."";
                      if($this->db != null)
                        {
                              return $this->db->exec($sql);
                        }else{
                        return null;
                        }
               }

            public function ifCategorieexiste($categorie){
                $sql = "SELECT * FROM v_categorie WHERE id_service='".$categorie->getId_service()."' and categorie.nom_categorie =  '".$categorie->getNom_categorie()."' ";
                if($this->db != null)
                {
                    if($this->db->query($sql)->fetch() != null)
                    {
                        return 1;
                    }
                }
                return 0;
            }
            public function fldeleteCategorie($id){
                $sql = "UPDATE categorie  SET  article.flag_categorie = 1  WHERE   categorie.id =  ".$id."  ";
                if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
            public function nbrArticleupdate($categorie){

                $id=$categorie->getId();
                $nbr=$categorie->getNbr_produit_categorie();
                $sql = "UPDATE categorie SET categorie.nbr_produit_categorie = ".$nbr." WHERE categorie.id = ".$id." ";

                if($this->db != null)
                {
                    return $this->db->exec($sql);
                }else{
                    return null;
                }
            }
           }
  
   



   ?>



