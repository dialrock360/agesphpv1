<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\entities;
    /*==================Classe creer par Samane samane_ui_admin le 05-11-2019 10:06:15=====================*/
        class Tache
            {

    /*==================Attribut list=====================*/
                
             private  $id;
             private  $id_projet;
             private  $nom_tache;
             private  $ls_membre_tache;
             private  $date_tache;
             private  $datelimit_tache;
             private  $etiquette_tache;
             private  $etat_tache;
             private  $info_tache;


             private  $projet;


    /*================== Constructor =====================*/
              public function __construct()
                 {
                 $this->projet = new Projet();
                 }


    /*==================Getter list=====================*/
                
             public function getId()
                 {
                     return $this->id;
                 }

             public function getId_projet()
                 {
                     return $this->id_projet;
                 }

             public function getNom_tache()
                 {
                     return $this->nom_tache;
                 }

             public function getLs_membre_tache()
                 {
                     return $this->ls_membre_tache;
                 }

             public function getDate_tache()
                 {
                     return $this->date_tache;
                 }

             public function getDatelimit_tache()
                 {
                     return $this->datelimit_tache;
                 }

             public function getEtiquette_tache()
                 {
                     return $this->etiquette_tache;
                 }

             public function getEtat_tache()
                 {
                     return $this->etat_tache;
                 }

             public function getInfo_tache()
                 {
                     return $this->info_tache;
                 }


             public function getProjet()
                 {
                     return $this->projet;
                 }
     

    /*==================Setter list=====================*/
                
             public function setId($id)
                 {
                      $this->id = $id;
                 }

             public function setId_projet($id_projet)
                 {
                      $this->id_projet = $id_projet;
                 }

             public function setNom_tache($nom_tache)
                 {
                      $this->nom_tache = $nom_tache;
                 }

             public function setLs_membre_tache($ls_membre_tache)
                 {
                      $this->ls_membre_tache = $ls_membre_tache;
                 }

             public function setDate_tache($date_tache)
                 {
                      $this->date_tache = $date_tache;
                 }

             public function setDatelimit_tache($datelimit_tache)
                 {
                      $this->datelimit_tache = $datelimit_tache;
                 }

             public function setEtiquette_tache($etiquette_tache)
                 {
                      $this->etiquette_tache = $etiquette_tache;
                 }

             public function setEtat_tache($etat_tache)
                 {
                      $this->etat_tache = $etat_tache;
                 }

             public function setInfo_tache($info_tache)
                 {
                      $this->info_tache = $info_tache;
                 }



             public function setProjet($projet)
                 {
                      $this->projet = $projet;
                 }

     

    /*==================Methode list=====================*/
           }
  
   



   ?>



