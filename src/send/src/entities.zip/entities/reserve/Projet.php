<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\entities;
    /*==================Classe creer par Samane samane_ui_admin le 05-11-2019 10:06:15=====================*/
        class Projet
            {

    /*==================Attribut list=====================*/
                
             private  $id;
             private  $id_programme;
             private  $id_type_projet;
             private  $id_equipe;
             private  $nom_projet;
             private  $cout_projet;
             private  $valeur_projet;
             private  $date_projet;
             private  $datefin_projet;
             private  $color_projet;
             private  $etat_projet;
             private  $flag_projet;


             private  $equipe;
             private  $programme;
             private  $type_projet;


    /*================== Constructor =====================*/
              public function __construct()
                 {
                 $this->equipe = new Equipe();
                 $this->programme = new Programme();
                 $this->type_projet = new Type_projet();
                 }


    /*==================Getter list=====================*/
                
             public function getId()
                 {
                     return $this->id;
                 }

             public function getId_programme()
                 {
                     return $this->id_programme;
                 }

             public function getId_type_projet()
                 {
                     return $this->id_type_projet;
                 }

             public function getId_equipe()
                 {
                     return $this->id_equipe;
                 }

             public function getNom_projet()
                 {
                     return $this->nom_projet;
                 }

             public function getCout_projet()
                 {
                     return $this->cout_projet;
                 }

             public function getValeur_projet()
                 {
                     return $this->valeur_projet;
                 }

             public function getDate_projet()
                 {
                     return $this->date_projet;
                 }

             public function getDatefin_projet()
                 {
                     return $this->datefin_projet;
                 }

             public function getColor_projet()
                 {
                     return $this->color_projet;
                 }

             public function getEtat_projet()
                 {
                     return $this->etat_projet;
                 }

             public function getFlag_projet()
                 {
                     return $this->flag_projet;
                 }


             public function getEquipe()
                 {
                     return $this->equipe;
                 }
             public function getProgramme()
                 {
                     return $this->programme;
                 }
             public function getType_projet()
                 {
                     return $this->type_projet;
                 }
     

    /*==================Setter list=====================*/
                
             public function setId($id)
                 {
                      $this->id = $id;
                 }

             public function setId_programme($id_programme)
                 {
                      $this->id_programme = $id_programme;
                 }

             public function setId_type_projet($id_type_projet)
                 {
                      $this->id_type_projet = $id_type_projet;
                 }

             public function setId_equipe($id_equipe)
                 {
                      $this->id_equipe = $id_equipe;
                 }

             public function setNom_projet($nom_projet)
                 {
                      $this->nom_projet = $nom_projet;
                 }

             public function setCout_projet($cout_projet)
                 {
                      $this->cout_projet = $cout_projet;
                 }

             public function setValeur_projet($valeur_projet)
                 {
                      $this->valeur_projet = $valeur_projet;
                 }

             public function setDate_projet($date_projet)
                 {
                      $this->date_projet = $date_projet;
                 }

             public function setDatefin_projet($datefin_projet)
                 {
                      $this->datefin_projet = $datefin_projet;
                 }

             public function setColor_projet($color_projet)
                 {
                      $this->color_projet = $color_projet;
                 }

             public function setEtat_projet($etat_projet)
                 {
                      $this->etat_projet = $etat_projet;
                 }

             public function setFlag_projet($flag_projet)
                 {
                      $this->flag_projet = $flag_projet;
                 }



             public function setEquipe($equipe)
                 {
                      $this->equipe = $equipe;
                 }

             public function setProgramme($programme)
                 {
                      $this->programme = $programme;
                 }

             public function setType_projet($type_projet)
                 {
                      $this->type_projet = $type_projet;
                 }

     

    /*==================Methode list=====================*/
           }
  
   



   ?>



