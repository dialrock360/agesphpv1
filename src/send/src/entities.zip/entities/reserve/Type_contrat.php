<?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



     namespace src\entities;
    /*==================Classe creer par Samane samane_ui_admin le 05-11-2019 09:57:12=====================*/
        class Type_contrat
            {

    /*==================Attribut list=====================*/
                
             private  $id;
             private  $nom_type_contrat;


    /*==================Getter list=====================*/
                
             public function getId()
                 {
                     return $this->id;
                 }

             public function getNom_type_contrat()
                 {
                     return $this->nom_type_contrat;
                 }


    /*==================Setter list=====================*/
                
             public function setId($id)
                 {
                      $this->id = $id;
                 }

             public function setNom_type_contrat($nom_type_contrat)
                 {
                      $this->nom_type_contrat = $nom_type_contrat;
                 }



    /*==================Methode list=====================*/
           }
  
   



   ?>



