

<?php

$cpt=0;
$cpt2=0;
$total = $_POST['total'];
