

<?php
$nommv = $_POST['type'];
$cacher = $_POST['cacher'];

$idcom = $_POST['idacom'];
$opt = $_POST['option'];

$flag=0;
$idmv = $_POST['idF'];
$nommv = $_POST['type'];
$obj = htmlspecialchars($_POST['objet']);