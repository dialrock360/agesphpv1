<?php

$idn = $_POST["idn"];
$nom = $_POST["Aname$i"];
$color = $_POST["Bname$i"];
$dep=0;$gain=0;$stk=0;
$val='nom';


?>