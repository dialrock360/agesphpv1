<?php
$cible='recu';
$docTb='rec';
$fac='rec';
$com='Fournisseur';

$mvmdb = new Mouvement();
$listemvm  = $mvmdb->listebyname($cible);


$prddb = new Produit();
$optionrecprd  = $prddb->optionProduit('rec');
$optionchargeprd  = $prddb->optionProduit('charge');
$target='?file=page/recu/table';



 if(isset($_GET['file'])) {
             switch ($_GET['file']) {
                 case 'page/recu':
                        require_once 'recu/reccontent.php';
                     break;
                 case 'page/recu/table':
                        require_once 'recu/tablereccontent.php';

                     break;
                 default:
                     header("location:$base_url");
                     break;
             }
         }
?>
<?php
require_once 'bloc/scriptfac.php';
?>
