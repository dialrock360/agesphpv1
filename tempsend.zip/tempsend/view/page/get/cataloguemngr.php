<?php
 
$dburl='../../../model/DB.php';
require_once '../../../classes/classeinclude.php';
require_once '../../../model/include.php';
require_once '../../../model/DB.php';
require_once '../../../assets/web/rooting.php';



if(($_POST['action'] == 'edit') && !empty($_POST['id'])){
     $OldTable=array();
     $update=0;
	  $prddb = new Produit();
 
      $idp = $_POST['id']; 
      $update=0;
      extract($_POST);
	
	  $prddb->setIdp($idp);
	  $OldTable=$prddb->get();
	  	         $prddb->setIdc($IDC) ;
                 $prddb->setId_cat($ID_CAT) ;
                 $prddb->setDesi($DESI) ;
                 $prddb->setPhoto($PHOTO) ;
                 $prddb->setPrixa($PRIXA) ;
                 $prddb->setPrixv($PRIXV) ;
                 $prddb->setQnt($QNT) ;
                 $prddb->setComposer($COMPOSER) ;
                 $prddb->setFtech($FTECH) ;
                 $prddb->setFlag($FLAG) ;
				 $update= $prddb->handlerupdate();
	  $returnData = array(
            'status' => 'error',
            //'msg' => 'Problème de modification essayer encore..',
            'msg' => 'Problème de modification essayer encore..',
            'data' => ''
        );
	 
	  if($update > 0 ){
        $returnData = array(
            'status' => 'ok',
            'msg' => 'User data has been updated successfully.',
            'data' => $userData
        );
      } 
   echo json_encode( $returnData); 

}


/*
if(($_POST['action'] == 'edit') && !empty($_POST['id'])){
	

	
	 if ( $idp>0){}

                  

    echo json_encode($returnData);  
			 }
	    
	 }*/