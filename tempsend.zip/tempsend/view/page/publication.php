
<?php

 require_once 'publication/uploadcontent.php';
?>
<?php
require_once 'bloc/scriptpublication.php';
?>
