<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Liste Des Matières</h4>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-hover table-striped">
                        <thead>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>coef</th>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>Php</td>
                            <td>7</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Java</td>
                            <td>6</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>C++</td>
                            <td>4</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Pithon</td>
                            <td>5</td>
                        </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>



    </div>
</div>