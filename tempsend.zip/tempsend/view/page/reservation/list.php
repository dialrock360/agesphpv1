
    <table align="center" border="1" cellpadding="1" cellspacing="1" style="width:1000px">
        <thead>
        <tr>
            <th colspan="5" scope="col">
                liste&nbsp; &nbsp;des&nbsp; &quot; typerdv&quot;&nbsp; du&nbsp;&nbsp;<strong>&quot; daterdv&quot;&nbsp;</strong>
            </th>
        </tr>
        <tr> <th scope="col"><strong>Clien</strong></th>
            <th scope="col"><strong>Email</strong></th>
            <th scope="col"><strong>Tel</strong></th>
            <th scope="col"><strong>Contenu</strong></th>
            <th scope="col"><strong>Statut</strong></th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td> <h4><strong>Nomduclient</strong></h4> </td>
            <td> <h4><strong>Emailduclient&nbsp;</strong></h4> </td>
            <td> <h4>777777777</h4> </td>
            <td> conten </td>
            <td>xxxxxxxx</td>
        </tr>
        </tbody>
    </table>


