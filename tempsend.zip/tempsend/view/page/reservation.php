<?php
require_once 'reservation/rdvcontent.php';
?>
<?php
require_once 'bloc/scriptrdv.php';
?>
