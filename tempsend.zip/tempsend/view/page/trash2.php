<?php
require_once 'corbeille/trashcontent2.php';
?>
<?php
require_once 'bloc/scriptrash.php';
?>
