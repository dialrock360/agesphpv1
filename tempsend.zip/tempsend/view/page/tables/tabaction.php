
<div class="btn-group btn-group-sm">
    <a href="javascript:void(0)" data-toggle="tooltip"  class="allcancelBtn" title="anuller" style="display: none">
        <i class="glyphicon glyphicon-remove red"></i>
    </a>

    <a href="javascript:void(0)" data-toggle="tooltip"  class="allconfirmBtn" title="valider" style="display: none">
        <i class="glyphicon glyphicon-ok green"></i>
    </a>
</div>


<input type="checkbox" id="Allpcheck" class="checkall" >
<input type="hidden" id="tabinfo" value="produit IDP restor mdelete" >

<a id="getMPrd" onclick="getMpro()" data-toggle="modal" class="alledit" data-target="#view-modal" data-id=" "  href="javascript:void(0)" data-toggle="tooltip" title="Modification Multiple"><span> <i class="glyphicon glyphicon-edit  bigger-120 green"></i></span> </a>


<a class="tab alldeleteBtn" href="javascript:void(0)" data-toggle="tooltip" id='delete' title="Supprimer">
    <span><i class="glyphicon glyphicon-trash  bigger-120 red"></i></span>
</a>
