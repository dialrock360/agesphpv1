<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="header">
                    <h4 class="title">Liste des Etudiants</h4>
                </div>
                <div class="content table-responsive table-full-width">
                    <table class="table table-hover table-striped">
                        <thead>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Genre</th>
                        <th>Date de Naissance</th>
                        <th>Tel</th>
                        </thead>
                        <tbody>
                        <tr>
                            <td>1</td>
                            <td>Dakota</td>
                            <td>Rice</td>
                            <td>12/06/1998</td>
                            <td>Femme</td>
                            <td>778855879</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Minerva </td>
                            <td>Hooper</td>
                            <td>10/08/1994</td>
                            <td>Homme</td>
                            <td>776853874</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Sage </td>
                            <td>Rodriguez</td>
                            <td>17/08/1995</td>
                            <td>Femme</td>
                            <td>777854849</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Philip </td>
                            <td>Chaney</td>
                            <td>10/08/1996</td>
                            <td>Homme</td>
                            <td>779853798</td>
                        </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>



    </div>
</div>