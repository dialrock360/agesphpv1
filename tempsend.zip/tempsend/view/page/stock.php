

<?php



$prddb = new Produit();
$catdb = new Categorie();
$condisdb = new Condis();
$famdb = new Famille();
$prdcomdb = new Produit_cmp();
$Optioncat= optionVarier('cat');
$Optioncondis= optionVarier('condis');
$Optionprd= optionVarier('prd');
$Optioncomposer= optionVarier('noprdcmp');
$Optionfam= optionVarier('fam');

 require_once 'stock/stockcontent.php';
?>
<?php
require_once 'bloc/scripstock.php';
?>


