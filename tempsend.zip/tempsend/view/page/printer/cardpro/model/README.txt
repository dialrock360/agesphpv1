A Pen created at CodePen.io. You can find this one at https://codepen.io/gil--/pen/yakNqZ.

 Youtube Video: https://www.youtube.com/watch?v=BCoqIwNHnzM

Dribbble Post: https://dribbble.com/shots/2850587-Daily-UI-002-Credit-Card

Github Source:   https://github.com/gil--/CSS-Snackables