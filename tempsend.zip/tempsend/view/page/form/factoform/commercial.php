<div class="element">
            <span class="add-on" style=" font-size:10px;font-family:Verdana, Arial, Helvetica, sans-serif;">Client <i class="fa fa-users bigger-110"></i>
 <select class="form-control" name="idacom" style="opacity:0.9;display: inline-block"required>
                <?php   Select_Cli(); ?>

            </select>
                                    </span>
</div>
