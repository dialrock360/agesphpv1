<?php
require_once 'corbeille/trashcontent.php';
?>
<?php
require_once 'bloc/scriptrash.php';
?>
