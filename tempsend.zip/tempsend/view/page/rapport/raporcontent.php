<style>
    #user,#cli,#four,#formcli,#formfour{
        display: none;
    }
</style>
<?php
$fac='prof';
?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="row">
                <div class="col-xs-12">


                    <!-- div.dataTables_borderWrap -->
                    <div>

                        <div    id="formDpro" >

                            <?php require_once 'form/formraport.php';
                            ?>

                        </div>
                        <?php   //require_once 'formpro.php';
                        ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div><!-- /.row -->