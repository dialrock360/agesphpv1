<?php


require_once 'Categorie.php';
require_once 'Condis.php';
require_once 'Department.php';
require_once 'Etat_compte.php';
require_once 'Etat_stock.php';
require_once 'Facture.php';
require_once 'Famille.php';
require_once 'Fond.php';
require_once 'Frontend.php';
require_once 'Image.php';
require_once 'Log.php';
require_once 'Mouvement.php';
require_once 'Notification.php';
require_once 'Poste.php';
require_once 'Produit.php';
require_once 'Produit_cmp.php';
require_once 'Service.php';
require_once 'Utilisateur.php';

?>