 <?php

    /*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    VOUS ETES LIBRE DE TOUTE UTILISATION
    Document redefini par samane_ui_admin de Pierre Yem Mback dialrock360@gmail.com
    ==================================================*/



    function connexion_params(){
        return array(
           'host' => '127.0.0.1',
           'user' => 'root',
           'password' => '',
           'database_name' => 'senbd',
           'etat' => 'on'//metter à on pour demarrer la base
    );
   }



   ?>



